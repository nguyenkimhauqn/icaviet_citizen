<?php if($rep): ?>
    <div>
        <img src="<?php echo e($rep['photo_origin_url']); ?>" alt="Photo" width="100">
        <h2><?php echo e($rep['first_name']); ?> <?php echo e($rep['last_name']); ?></h2>
        <p>Đảng: <?php echo e($rep['party']); ?></p>
        <a href="<?php echo e($rep['web_form_url']); ?>">Liên hệ</a>
    </div>
<?php else: ?>
    <p>Không tìm thấy đại diện cho mã ZIP: <?php echo e($zip); ?></p>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/representative/rep.blade.php ENDPATH**/ ?>