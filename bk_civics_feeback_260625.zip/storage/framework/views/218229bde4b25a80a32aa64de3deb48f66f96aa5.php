<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(URL('public/css/results.css')); ?>">
    <div class="container py-5">
        
        <div class="wp-header d-flex align-items-end mb-4">
            <div class="btn-home mr-2">
                <a href="<?php echo e(route('civics.results.index')); ?>"
                    class="btn btn-outline-dark rounded-circle d-flex align-items-center justify-content-center"
                    title="Quay về trang chủ" style="width: 48px; height: 48px;">
                    <i class="bi bi-arrow-left-circle-fill fs-3"></i>
                </a>
            </div>
            <div class="flex justify-between items-center header-civics">
                <h3 class="text-2xl font-bold text-gray-800"> Chi tiết bài kiểm tra</h3>
            </div>
        </div>

        <?php $__currentLoopData = $quizQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $question = $item->question;
                $answers = $question->answers;
                $selected = $item->user_answer_id;
                $correctId = $answers->firstWhere('is_correct', true)?->id;
                $isCorrect = $item->is_correct;
                $isStarred = in_array($question->id, $starredIds);
            ?>

            <div class="mb-4 p-3 border rounded shadow-sm">
                <div class="d-flex justify-content-between align-items-start">
                    <div class="fw-bold">
                        <?php echo e($loop->iteration); ?>. <?php echo e($question->content); ?>

                        <?php if($isStarred): ?>
                            <span class="text-warning ms-2">⭐</span>
                        <?php endif; ?>
                    </div>
                    <div class="badge <?php echo e($isCorrect ? 'bg-success' : 'bg-danger'); ?>">
                        <?php echo e($isCorrect ? 'ĐÚNG' : 'SAI'); ?>

                    </div>
                </div>

                <ul class="list-group mt-3">
                    <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $isUserAnswer = $ans->id == $selected;
                            $isAnswerCorrect = $ans->is_correct;
                            $class = 'list-group-item';

                            if ($isUserAnswer && $isAnswerCorrect) {
                                $class .= ' list-group-item-success';
                            } elseif ($isUserAnswer && !$isAnswerCorrect) {
                                $class .= ' list-group-item-danger';
                            } elseif (!$isUserAnswer && $isAnswerCorrect) {
                                $class .= ' list-group-item-success text-muted';
                            }
                        ?>
                        <li class="<?php echo e($class); ?>">
                            <?php if($isUserAnswer): ?>
                                <strong>🟢</strong>
                            <?php endif; ?>
                            <?php echo e($ans->content); ?>

                            <?php if($isAnswerCorrect && !$isUserAnswer): ?>
                                <span class="ms-2">(Đáp án đúng)</span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/results/show.blade.php ENDPATH**/ ?>