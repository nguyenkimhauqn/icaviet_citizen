<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/writing.css')); ?>">

    <div class="container max-w-2xl mx-auto px-4 py-6">
        
        <div class="wp-header d-flex align-items-end mb-4">
            <div class="btn-home mr-2">
                <a href="<?php echo e(route('home')); ?>"
                    class="btn btn-outline-dark rounded-circle d-flex align-items-center justify-content-center"
                    title="Quay về trang chủ" style="width: 48px; height: 48px;">
                    <i class="bi bi-arrow-left-circle-fill fs-3"></i>
                </a>
            </div>
            <div class="flex justify-between items-center header-civics">
                <h3 class="text-2xl font-bold text-gray-800"> KIỂM TRA VIẾT </h3>
            </div>
        </div>

        
        <div class="sp-bt">
            <div class="mb-2 text-base">
                <span class="highlight-text"> Câu hỏi <?php echo e($index + 1); ?> </span> / <span class="highlight-text">
                    <?php echo e($total); ?> </span>
            </div>
        </div>

        
        <form action=" <?php echo e(route('writing.check')); ?> " method="POST">
            <?php echo csrf_field(); ?>
            <div class="question-block">
                <div class="wp-question fl-item flex justify-center items-center my-6">
                    
                    <img class="img-fluid img-loudspeaker play-audio-btn" src="<?php echo e(url('public/icon/loudspeaker.png')); ?>"
                        data-audio="<?php echo e(asset('public/audio/writing/' . $question->audio_path)); ?>" alt="icon_loudspeaker">
                    
                    <audio id="audio-player" src="<?php echo e(asset('public/audio/writing/' . $question->audio_path)); ?>"></audio>
                    
                    <h5 id="icon-show">
                        <i class="bi bi-toggle-off toggle-icon"></i>
                    </h5>
                    
                    <p id="writing-answer" class="d-none hidden italic text-center mt-2"><?php echo e($question->content); ?></p>
                    
                    <?php if(session('result') !== null): ?>
                        <div class="text-center mt-4 font-semibold">
                            <?php if(empty(session('input_answer'))): ?>
                                <div class="alert alert-warning d-inline-block" role="alert">
                                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                                    Nhập đáp án của bạn
                                </div>
                            <?php elseif(session('result')): ?>
                                <div class="alert alert-success d-inline-block" role="alert">
                                    <i class="bi bi-check-circle-fill me-2"></i>
                                    Chính xác!
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger d-inline-block" role="alert">
                                    <i class="bi bi-x-circle-fill me-2"></i>
                                    Sai rồi!
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mt-2 flex fl-item">
                        <input type="hidden" name="index" value="<?php echo e($index); ?>">
                        <textarea name="user_answer"
                            class="input-writing form-control text-lg px-4 border rounded textarea-writing text-lg px-4 py-2 border rounded"
                            rows="1" placeholder="Viết câu trả lời của bạn..."> <?php echo e(old('user_answer', session('input_answer'))); ?> </textarea>
                    </div>
                    
                    <div class="wp-action justify-between items-center mt-4">
                        
                        <a href="<?php echo e(route('writing.show', ['index' => ($index - 1 + $total) % $total])); ?>"
                            class="btn btn-primary">
                            ← Trước
                        </a>
                        
                        <button type="submit" class="btn btn-secondary btn-submit">
                            ✓ Kiểm tra
                        </button>

                        <a href="<?php echo e(route('writing.show', ['index' => ($index + 1) % $total])); ?>" class="btn btn-primary">
                            Tiếp →
                        </a>
                    </div>
                </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            // === * 01. Xử lý Toogle đáp án * ===
            $('#icon-show').on('click', function(e) {
                e.preventDefault();
                const answer = $('#writing-answer');
                answer.toggleClass('d-none d-block');
                $('#icon-show i').toggleClass('bi-toggle-off bi-toggle-on');
            });
            // === * [END] 01. Xử lý Toogle đáp án * ===

            // === * 02. Xử lý nút phát audio * ===
            // Phát tự động câu hỏi khi vào trang
            // Phát tự động audio CÂU HỎI nếu chưa từng phát
            if (!sessionStorage.getItem('playedAudio')) {
                const autoPlayBtn = $('.play-audio-btn').first();
                if (autoPlayBtn.length) {
                    const audioSrc = autoPlayBtn.data('audio');
                    const autoAudio = new Audio(audioSrc);
                    autoAudio.play().then(() => {
                        sessionStorage.setItem('playedAudio', 'true');
                    }).catch(function(e) {
                        console.warn('Autoplay bị chặn bởi trình duyệt:', e);
                    });
                }
            }
            // Khi bấm nút “Trước” hoặc “Tiếp”, reset lại trạng thái
            $('.wp-action a').on('click', function() {
                sessionStorage.removeItem('playedAudio');
            });

            // Phát âm câu hỏi
            $('.play-audio-btn').on('click', function() {
                let audioSrc = $(this).data('audio');
                let audio = new Audio(audioSrc);
                if (audio.paused) {
                    audio.play();
                }
            });
            // === * [END] - Xử lý nút phát audio * ===
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/writing/show.blade.php ENDPATH**/ ?>