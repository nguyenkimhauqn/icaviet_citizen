<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h2 class="mb-3">🔍 Nhập mã ZIP của bạn</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger"><?php echo e($errors->first('zip')); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('zip.lookup')); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="zip" maxlength="5" class="form-control w-25 mb-3" placeholder="Ví dụ: 90001">
        <button type="submit" class="btn btn-primary">Xem đại diện</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/lookup/form.blade.php ENDPATH**/ ?>