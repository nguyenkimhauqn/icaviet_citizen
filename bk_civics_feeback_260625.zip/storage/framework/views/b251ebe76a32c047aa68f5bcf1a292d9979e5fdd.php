<?php $__env->startSection('content'); ?>
    <div class="container text-center">

        <h3 class="titleState fs-2"> <?php echo e($state); ?><br><span class="fw-bold fs-4"><?php echo e($zip); ?></span></h3>

        
        <div class="card-box my-3 p-3">
            <h5 class=" text-primary"> <strong> Representative </strong> (Dân biểu) </h5>
            <a class="link-website" href="https://www.house.gov" target="_blank">www.house.gov</a>
            <?php if($representative): ?>
                <div class="d-flex align-items-center mt-2">
                    <img src="<?php echo e($representative['photo_origin_url'] ?? 'https://via.placeholder.com/80'); ?>" alt="Rep"
                        class="rounded shadow-sm" width="100" height="100">
                    <div class="ms-3 text-start align-items-start">
                        <h6 class="mb-1"><?php echo e($representative['first_name']); ?> <?php echo e($representative['last_name']); ?></h6>
                        <p class="mb-0"><?php echo e($representative['party']); ?></p>
                        <p class="mb-0 fst-italic">
                            <?php echo e(Str::contains($representative['party'], 'Republican') ? '(Đảng Cộng hòa)' : '(Đảng Dân chủ)'); ?>

                        </p>
                    </div>
                </div>
            <?php else: ?>
                <p>Không tìm thấy.</p>
            <?php endif; ?>
        </div>

        
        <div class="card-box my-3 p-3">
            <h5 class="text-primary"> <strong> Senators </strong> (Thượng nghị sĩ) </h5>
            <a class="link-website" href="https://www.senate.gov" target="_blank">www.senate.gov</a>
            <?php $__empty_1 = true; $__currentLoopData = $senators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $senator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="d-flex align-items-center mt-2">
                    <img src="<?php echo e($senator['photo_origin_url'] ?? 'https://via.placeholder.com/80'); ?>" alt="Senator"
                        class="rounded shadow-sm" width="100" height="100">
                    <div class="ms-3 text-start">
                        <h6 class="mb-1"><?php echo e($senator['first_name']); ?> <?php echo e($senator['last_name']); ?></h6>
                        <p class="mb-0"><?php echo e($senator['party']); ?></p>
                        <p class="mb-0 fst-italic">
                            <?php echo e(Str::contains($senator['party'], 'Republican') ? '(Đảng Cộng hòa)' : '(Đảng Dân chủ)'); ?>

                        </p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Không tìm thấy.</p>
            <?php endif; ?>
        </div>

        
        <div class="card-box my-3 p-3">
            <h5 class="text-primary"> <strong> Governor </strong> (Thống đốc)</h5>
            <a class="link-website" href="https://www.nga.org/governors" target="_blank">www.nga.org/governors</a>
            <?php if($governor): ?>
                <div class="d-flex align-items-center mt-2">
                    <img src="<?php echo e($governor['photo_origin_url'] ?? 'https://via.placeholder.com/80'); ?>" alt="Governor"
                        class="rounded shadow-sm" width="100" height="100">
                    <div class="ms-3 text-start">
                        <h6 class="mb-1"><?php echo e($governor['first_name']); ?> <?php echo e($governor['last_name']); ?></h6>
                        <p class="mb-0"><?php echo e($governor['party']); ?></p>
                        <p class="mb-0 fst-italic">
                            <?php echo e(Str::contains($senator['party'], 'Republican') ? '(Đảng Cộng hòa)' : '(Đảng Dân chủ)'); ?>

                        </p>
                    </div>
                </div>
            <?php else: ?>
                <p>Không tìm thấy.</p>
            <?php endif; ?>
        </div>

        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Tiếp theo </a>

    </div>
    <style>
        .wp-content {
            background-color: #F5F4FAE5;
        }

        .titleState {
            padding-top: 40px;
            text-transform: uppercase;
        }

        .card-box {
            background-color: #FFFFFF;
            border: solid 1px #FFFFFF;
            border-radius: 12px;
            box-shadow: 0px 4px 5px rgba(0, 0, 0, 0.05);
        }

        a.btn.btn-primary {
            font-weight: bold; /* hoặc: 600, 700 */
            padding: 15px 40px;
            padding: 15px 40px;
            margin-top: 40px;
            margin-bottom: 50px;
        }

        .text-primary,
        .link-website {
            color: #1247BB !important;
        }

        h6 {
            font-weight: 800;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/representative/results.blade.php ENDPATH**/ ?>