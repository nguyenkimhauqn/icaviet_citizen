<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/css/reading.css')); ?>">
    <div class="container max-w-2xl mx-auto px-4 py-6">
        
        <div class="wp-header d-flex align-items-end mb-4">
            <div class="btn-home mr-2">
                <a href="<?php echo e(route('home')); ?>"
                    class="btn btn-outline-dark rounded-circle d-flex align-items-center justify-content-center"
                    title="Quay về trang chủ" style="width: 48px; height: 48px;">
                    <i class="bi bi-arrow-left-circle-fill fs-3"></i>
                </a>
            </div>
            <div class="flex justify-between items-center header-civics">
                <h3 class="text-2xl font-bold text-gray-800"> KIỂM TRA ĐỌC </h3>
            </div>
        </div>

        
        <div class="sp-bt">
            <div class="mb-2 text-base">
                <span class="highlight-text"> Câu hỏi <?php echo e($index + 1); ?> </span> / <span class="highlight-text">
                    <?php echo e($total ?? ''); ?> </span>
            </div>
        </div>

        
        <div class="question-block">
            <div class="wp-question fl-item flex justify-center items-center my-6">
                
                <img class="img-fluid img-loudspeaker play-audio-btn" src="<?php echo e(url('public/icon/loudspeaker.png')); ?>"
                    data-audio="<?php echo e(asset('public/audio/reading/' . $question->audio_path)); ?>" alt="icon_loudspeaker">

                
                <p id="writing-answer" class=" italic text-center mt-2">
                    <?php echo e($question->content ?? ''); ?>

                </p>
                
                <div id="box-speech-result" class="bg-light box-speech-result text-center mt-1">
                    <span id="speech-result" class="px-3 py-2 d-inline-block">
                        Nhấn vào micro và đọc câu!
                    </span>
                </div>
                
                <div class="wp-action justify-between items-center mt-4">
                    <button id="record-btn" class="btn btn-secondary">🎤 Thu âm</button>
                    <div id="record-status" class="mt-2 text-gray-700">Bấm để bắt đầu ghi âm</div>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {

            // === 01. Tự động phát audio 1 lần ===
            if (!sessionStorage.getItem('playedAudio')) {
                const autoPlayBtn = $('.play-audio-btn').first();
                if (autoPlayBtn.length) {
                    const audioSrc = autoPlayBtn.data('audio');
                    const autoAudio = new Audio(audioSrc);
                    autoAudio.play().then(() => {
                        sessionStorage.setItem('playedAudio', 'true');
                    }).catch(function(e) {
                        console.warn('Autoplay bị chặn bởi trình duyệt:', e);
                    });
                }
            }
            // Reset khi bấm nút chuyển câu
            $('.wp-action a').on('click', function() {
                sessionStorage.removeItem('playedAudio');
            });

            // === 02. Phát audio khi bấm loa ===
            $('.play-audio-btn').on('click', function() {
                let audioSrc = $(this).data('audio');
                let audio = new Audio(audioSrc);
                if (audio.paused) {
                    audio.play();
                }
            });

            let mediaRecorder;
            let audioChunks = [];

            const $recordBtn = document.getElementById('record-btn');
            const $recordStatus = document.getElementById('record-status');
            const $speechResult = document.getElementById('speech-result');

            // 1. Sự kiện khi người dùng bấm nút “Thu âm”
            $recordBtn.addEventListener('click', async function() {
                $recordStatus.textContent = '⏳ Đang ghi âm...';
                $recordBtn.disabled = true;
                $speechResult.textContent = ''; // Clear kết quả cũ nếu có

                try {
                    const stream = await navigator.mediaDevices.getUserMedia({
                        audio: true
                    });
                    mediaRecorder = new MediaRecorder(stream);
                    audioChunks = [];

                    mediaRecorder.addEventListener("dataavailable", event => {
                        audioChunks.push(event.data);
                    });

                    mediaRecorder.addEventListener("stop", () => {
                        const audioBlob = new Blob(audioChunks, {
                            type: 'audio/webm'
                        });
                        uploadAndCheck(audioBlob); // Gửi file lên server
                        $recordBtn.disabled = false;
                        $recordStatus.textContent = '✅ Đã ghi xong. Đang gửi dữ liệu...';
                    });

                    mediaRecorder.start();

                    // Ghi âm tối đa 5 giây
                    setTimeout(() => {
                        mediaRecorder.stop();
                    }, 5000);

                } catch (error) {
                    $recordStatus.textContent = '❌ Không thể truy cập micro.';
                    $recordBtn.disabled = false;
                    console.error("Mic error::", error);
                }
            });

            // 2. Gửi file ghi âm hình lên server laravel
            function uploadAndCheck(audioBlob) {
                const formData = new FormData();
                formData.append('audio', audioBlob, 'recording.webm');
                formData.append('_token', '<?php echo e(csrf_token()); ?>');

                $speechResult.textContent = '⏳ Đang gửi file...';

                $.ajax({
                    url: "<?php echo e(route('speech.upload')); ?>",
                    method: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(res) {
                        if (res.transcript_id) {
                            pollTranscript(res.transcript_id);
                        } else {
                            $speechResult.textContent = '❌ Không thể kiểm tra.';
                        }
                    },
                    error: function(xhr, status, error) {
                        $speechResult.textContent = '❌ Lỗi gửi dữ liệu.';
                        console.error("AJAX Error:", status, error);
                        console.log("Response Text:", xhr.responseText); // ← Xem rõ thông báo
                    }
                });
            }

            // 3. Gửi yêu cầu kiểm tra kết quả định kỳ
            function pollTranscript(id) {
                $speechResult.textContent = '⏳ Đang phân tích...';
                const poll = setInterval(() => {
                    $.get(`/reading/result/${id}`, function(res) {
                        if (res.status === 'completed') {
                            clearInterval(poll);
                            $speechResult.textContent = res.transcript;

                            $speechResult.classList.remove('bg-light', 'bg-success', 'bg-danger');
                            $speechResult.classList.add(res.matched ? 'bg-success' : 'bg-danger');
                        } else if (res.status === 'error') {
                            clearInterval(poll);
                            $speechResult.textContent = '❌ Lỗi khi phân tích';
                        }
                    });
                }, 3000);
            }
            // [END] 03. - Speech to Text
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/reading/test.blade.php ENDPATH**/ ?>