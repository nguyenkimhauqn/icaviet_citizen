<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/civics.css')); ?>">

    <div class="container mt-4">
        
        <div class="wp-header d-flex align-items-center mb-4">
            <div class="btn-home mr-2">
                <a href="<?php echo e(route('home')); ?>" class="" title="Quay về trang chủ" style="width: 42px; height: 42px;">
                    <img style="width: 50px; height: 50px;" src="<?php echo e(url('public/icon/Icon-back-home.svg')); ?>" alt="">
                </a>
            </div>
            <div class="flex justify-between items-center header-civics">
                <h3 class="heading-module text-2xl font-bold text-gray-800"> <?php echo $heading ?? ''; ?> </h3>
            </div>
        </div>

        
        <div class="process sp-bt d-flex justify-content-center">
            <div class="mb-2 text-base">
                <span class="">Câu hỏi </span> <span class="fw-bold"> <?php echo e($page); ?> /
                    <?php echo e($total); ?> </span>
            </div>
        </div>

        
        <div class="question-block ">
            <div class="flex justify-between items-start sp-bt">
                <div class="highlight-title"> <?php echo $question->content; ?> </div>
                <div class="flex space-x-3 ">
                    <span class="d-block text-blue-500 text-xl play-audio-btn"
                        data-audio="<?php echo e(asset('public/audio/civics/questions/' . $question->audio_path)); ?>"> <img
                            src="<?php echo e(url('public/icon/Speaker.svg')); ?>" alt="icon_speaker"> </span>
                    <span class="d-block toggle-star-btn <?php echo e($isStarred ? 'stared' : ''); ?> "
                        data-question-id=<?php echo e($question->id); ?> data-active=<?php echo e($isStarred ? '1' : '0'); ?>> <img
                            src="<?php echo e(url('public/icon/Icon _Starred.svg')); ?>" alt="icon_starred"> </span>
                </div>
            </div>
        </div>

        <div class="answer-block">
            
            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="answer answer-option answer-disabled" type="button" name="answer_id"
                    value="<?php echo e($answer->id); ?>">
                    
                    <?php
                        $dynamicContent = $answer->content;

                        if ($question->has_guideline && $answer->is_correct && isset($representativeData)) {
                            switch ($question->id) {
                                case 20: // Senator
                                    $senators = $representativeData->senators;
                                    if (is_array($senators) && count($senators) > 0) {
                                        $firstSenator = $senators[0];
                                        $dynamicContent =
                                            $firstSenator['first_name'] . ' ' . $firstSenator['last_name'];
                                    }
                                    break;
                                case 23: // Representative
                                    $rep = $representativeData->representative;
                                    if (is_array($rep)) {
                                        $dynamicContent = $rep['first_name'] . ' ' . $rep['last_name'];
                                    }
                                    break;
                                case 43: // Governor
                                    $gov = $representativeData->governor;
                                    if (is_array($gov)) {
                                        $dynamicContent = $gov['first_name'] . ' ' . $gov['last_name'];
                                    }
                                    break;
                                case 44: // Capital
                                    $dynamicContent = $representativeData->capital ?? $answer->content;
                                    break;
                            }
                        }
                    ?>

                    <div class="left-answer">
                        <?php echo e($dynamicContent); ?>

                    </div>
                    <?php if($answer->is_correct): ?>
                        <span id="play-audio-answer" class="text-blue-500 text-xl play-audio-answer"
                            data-answer-id="<?php echo e($answer->id); ?>"
                            data-audio="<?php echo e(asset('public/audio/civics/answers/' . $answer->audio_path)); ?>">
                            <img src="<?php echo e(url('public/icon/Icon_Speaker_answer.svg')); ?>" alt="icon_speaker">
                        </span>
                    <?php endif; ?>
                </button>
                <?php if($answer->explanation || $answer->pronunciation): ?>
                    <div id="trans-box" class="trans-box d-none">
                        <?php if($answer->explanation): ?>
                            <strong>Dịch:</strong> <?php echo e($answer->explanation); ?>

                        <?php endif; ?>
                        <?php if($answer->pronunciation): ?>
                            <p class="mt-2"><strong>Phát âm dễ nhớ:</strong> <?php echo e($answer->pronunciation); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <?php if($question->translation): ?>
            <p class="mt-2">
                <strong>Dịch:</strong> <?php echo e($question->translation); ?>

            </p>
        <?php endif; ?>
        <div class="container-tips">
            <?php if($question->tips): ?>
                <div class="tips-box">
                    <strong>
                        <p class="d-block"> Mẹo ghi nhớ: </p>
                    </strong>
                    <?php $__currentLoopData = json_decode($question->tips, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="answer-tips">
                            <span class="tag">
                                <span class="tag-key"><?php echo e($label . ':'); ?> </span> <span class="tag-value">
                                    <?php echo e($value); ?> </span>
                            </span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        
        <?php if($question->has_guideline): ?>
            <?php
                // Xác định link động theo ID
                $guidelineLinks = [
                    20 => 'https://www.senate.gov/senators/index.htm',
                    23 => 'https://www.house.gov/representatives',
                    43 => 'https://www.usa.gov/state-governor',
                ];
                $guidelineUrl = $guidelineLinks[$question->id] ?? null;
            ?>
            <div class="guideline-box mt-5 p-4 bg-white rounded-[20px] border-l-[9px] border-[#27AE60]">
                <p class="fw-bold mb-2 text-lg text-danger">
                    Lưu ý: Thông tin hiển thị dựa trên mã ZIP và dữ liệu công khai có thể không chính xác 100%.
                    Vui lòng kiểm tra lại trên trang web của chính phủ:
                </p>

                <?php if($guidelineUrl): ?>
                    <p class="text-base leading-relaxed">
                        <a href="<?php echo e($guidelineUrl); ?>" target="_blank" class="text-blue-600 underline">
                            <?php echo e($guidelineUrl); ?>

                        </a>
                    </p>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        
        <div class="d-flex justify-content-center mt-8 box-btn next-btn">
            <a href="<?php echo e($nextPageUrl); ?>" class="next-btn-circle">
                <i class="bi bi-chevron-right"></i>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            // === * Phát âm thanh * ===
            // Phát âm câu hỏi
            $('.play-audio-btn').on('click', function() {
                let audioSrc = $(this).data('audio');
                let audio = new Audio(audioSrc);
                if (audio.paused) {
                    audio.play();
                }
            });
            // Phát âm câu trả lời theo audio sẵn
            // $('.play-audio-answer').on('click', function() {
            //     alert(1);
            //     let audioSrc = $(this).data('audio');
            //     let audio = new Audio(audioSrc);
            //     if (audio.paused) {
            //         audio.play();
            //     }
            // });


            // Text to speech theo questions
            $('.play-audio-answer').on('click', function() {
                const answerText = $(this).closest('button').find('.left-answer').text().trim();
                let hasSpoken = false;

                const speak = (text) => {
                    if (hasSpoken) return;
                    hasSpoken = true;

                    const utterance = new SpeechSynthesisUtterance(text);
                    utterance.lang = 'en-US';
                    utterance.rate = 0.7;

                    const voices = speechSynthesis.getVoices();
                    const preferredVoices = [
                        'Google US English',
                        'Samantha',
                        'Microsoft Zira',
                        'Karen'
                    ];

                    const matched = voices.find(v => preferredVoices.includes(v.name));
                    const fallback = voices.find(v => v.lang === 'en-US' && v.name.toLowerCase()
                        .includes('female'));
                    const anyUS = voices.find(v => v.lang === 'en-US');

                    utterance.voice = matched || fallback || anyUS || null;
                    speechSynthesis.speak(utterance);
                };

                const voices = speechSynthesis.getVoices();
                if (voices.length === 0) {
                    // 🧠 Gán handler một lần duy nhất
                    const handleVoicesChanged = () => {
                        speak(answerText);
                        // 🚫 Xóa handler sau khi dùng xong
                        speechSynthesis.onvoiceschanged = null;
                    };

                    speechSynthesis.onvoiceschanged = handleVoicesChanged;
                } else {
                    speak(answerText);
                }
            });


            // Phát tự động câu hỏi khi vào trang
            const autoPlayBtn = $('.play-audio-btn').first(); // 1 cau
            if (autoPlayBtn.length) {
                const audioSrc = autoPlayBtn.data('audio');
                const autoAudio = new Audio(audioSrc);
                autoAudio.play().catch(function(e) {
                    console.warn('Autoplay bị chặn bởi trình duyệt:', e);
                });
            }
            // [END] - Phát âm thanh 

            // AJAX kiểm tra đáp án
            $('.answer-option').on('click', function(e) {
                e.preventDefault();
                const button = $(this);
                const answerId = button.val();
                const questionId = <?php echo e($question->id); ?>;

                $.ajax({
                    url: `<?php echo e(url('civics/answer')); ?>/${questionId}`,
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',
                        answer_id: answerId
                    },
                    success: function(res) {
                        if (!res.success) return alert('Có lỗi xảy ra.');

                        $('.answer-option').prop('disabled', true);
                        // $('.answer-option').css('pointer-events', 'none');
                        // Xử lý màu đáp án đúng & sai. 
                        $('.answer-option').each(function() {
                            const currentBtn = $(this);
                            const currentId = parseInt(currentBtn.val());
                            // Reset các màu cũ trước

                            // Trường hợp: Luôn hiển thị đáp án đúng
                            if (currentId === res.correct_answer_id) {
                                currentBtn.addClass(
                                    'bg-green-500 text-white answer-correct');

                            }
                            // Trường hợp: chọn sai
                            if (currentId === res.selected_answer_id && currentId !==
                                res.correct_answer_id) {
                                currentBtn.addClass(
                                    'bg-red-500 text-white answer-wrong');

                                // 🔊 Phát âm thanh sai
                                const wrongAudio = new Audio(
                                    '<?php echo e(asset('public/audio/civics/Wrong-answer.mp3')); ?>'
                                );
                                wrongAudio.play();
                            }
                            // Trường hợp: chọn đúng (phát âm đúng duy nhất một lần)
                            if (currentId === res.selected_answer_id && currentId ===
                                res.correct_answer_id) {

                                const correctAudio = $(
                                    `.play-audio-answer[data-answer-id="${currentId}"]`
                                );
                                correctAudio.css('display', 'block');

                                // 🔊 Phát âm thanh đúng
                                const correctSound = new Audio(
                                    '<?php echo e(asset('public/audio/civics/correct-answer.mp3')); ?>'
                                );
                                correctSound.play();

                                // Phát đáp án lưu trữ khi chọn đúng

                                // const audioPath = correctAudio.data('audio');
                                // const audio = new Audio(audioPath);
                                // audio.play();
                            }

                        });

                        // Hiển thị phần dịch & phát âm
                        $('#trans-box').removeClass('d-none').addClass('d-block');

                        // Hiển thị đáp án đúng khác
                        // tạm off
                        // if (res.is_correct && res.hints.length > 0) {
                        //     // console.log(res.hints);
                        //     res.hints.forEach(function(hint) {
                        //         console.log(hint);

                        //     });

                        //     let hinHtml =
                        //         '<div class=" p-2 rounded bg-green-50 text-sm text-gray-800">';
                        //     hinHtml +=
                        //         '<p class="font-semibold mb-2 text-green-700">Các cách trả lời đúng khác:</p>';
                        //     res.hints.forEach(function(hint) {
                        //         hinHtml += `<div class="pl-2">✅ ${hint}</div>`;
                        //     });
                        //     hinHtml += `</div>`;
                        //     // Gắn hint vào câu trả lời đúng
                        //     $(`[value='${res.correct_answer_id}']`).after(hinHtml);

                        // }

                    },
                    error: function() {
                        alert('Lỗi kết nối máy chủ.');
                    }
                });
            });
            // [END] - AJAX check 

            // Check Result
            $('.box-btn a').on('click', function(e) {
                const currentPage = <?php echo e($page); ?>; // so cau hien tai
                const totalQuestions = <?php echo e($total); ?> // tong so cau
                const mode = "<?php echo e($mode); ?>"; // 
                // alert(1);
                const routeQuizResult = "<?php echo e(route('civics.quizResult', ['quiz' => 'QUIZ_ID'])); ?>";
                const nextPage = currentPage + 1;
                if (nextPage > totalQuestions) {
                    e.preventDefault(); // stop move page
                    // alert(1);
                    // Gui AJAX
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(url('civics/finish-quiz')); ?>",
                        data: {
                            _token: " <?php echo e(csrf_token()); ?> "
                        },
                        dataType: "json",
                        success: function(res) {
                            if (res.success) {
                                // alert(1);
                                // console.log(ok);
                                const redirectUrl = routeQuizResult.replace('QUIZ_ID', res
                                    .quiz_id) + '?mode=' + mode;
                                // chuyen huong trang success:
                                window.location.href = redirectUrl;
                            } else {
                                alert("Không thể hoàn thành bài kiểm tra. Vui lòng thử lại!'");
                            }
                        },

                        error: function() {
                            alert("Loi ket noi may chu");
                        }
                    });
                }
            });
            // [END] - Check Result

            // === * Lưu câu hỏi đánh dấu sao * ===  

            //  --- Check isStarred ---
            const starBtn = $('.toggle-star-btn');
            if (parseInt(starBtn.data('active')) === 1) {
                starBtn.css('background', 'gold');
            } else {
                starBtn.css('background', '');
            }

            //  --- [END] Check isStarred ---
            $('.toggle-star-btn').on('click', function() {
                let btn = $(this);
                let questionId = btn.data('question-id');
                // alert(1);
                $.post("<?php echo e(url('civics/star')); ?>/" + questionId, {
                    _token: '<?php echo e(csrf_token()); ?>'
                }, function(res) {
                    // Xu ly phan hoi
                    // alert(res.status)
                    if (res.status === 'added') {
                        btn.css('background-color', 'gold');
                    } else {
                        btn.css('background-color', '');
                    }
                });
            });
            // [END] == * Lưu câu hỏi đánh dấu sao * ===  
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/civics/question.blade.php ENDPATH**/ ?>