<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(URL('public/css/results.css')); ?>">
    <div class="container py-4">
        
        <div class="wp-header d-flex align-items-end mb-4">
            <div class="btn-home mr-2">
                <a href="<?php echo e(route('home')); ?>"
                    class="btn btn-outline-dark rounded-circle d-flex align-items-center justify-content-center"
                    title="Quay về trang chủ" style="width: 48px; height: 48px;">
                    <i class="bi bi-arrow-left-circle-fill fs-3"></i>
                </a>
            </div>
            <div class="flex justify-between items-center header-civics">
                <h3 class="text-2xl font-bold text-gray-800 text-center"> KẾT QUẢ </h3>
            </div>
        </div>
        

        

        <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $percent =
                    $quiz->total_questions > 0 ? round(($quiz->correct_answers / $quiz->total_questions) * 100) : 0;

                $isPassed = $percent >= 60;
            ?>

            <div class="card mb-3 shadow-sm">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div class="text-start">
                        <a href="<?php echo e(route('civics.results.show', $quiz->id)); ?>">
                            <h5 class="mb-1">Bài kiểm tra <span class="text-primary"> <?php echo e($quiz->correct_answers); ?> </span>
                                /
                                <?php echo e($quiz->total_questions); ?> Câu hỏi</h5>
                            <small class="text-muted"><?php echo e($quiz->created_at->format('D, M d, Y h:i A')); ?></small>
                        </a>
                    </div>

                    <div class="text-end">
                        <div class="mb-2">
                            <span class="badge <?php echo e($isPassed ? 'bg-success' : 'bg-danger'); ?>">
                                <?php echo e($percent); ?>%
                            </span>
                        </div>
                        <div>
                            
                            <a href="<?php echo e(route('civics.results.show', $quiz->id)); ?>"
                                class="btn btn-sm btn-outline-secondary">
                                ➤
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/results/index.blade.php ENDPATH**/ ?>