<?php $__env->startSection('content'); ?>
    <button id="start">🎙️ Ghi âm</button>
    <button id="stop" disabled>⏹️ Dừng</button>

    <!-- iOS fallback -->
    <div id="ios-mode" class="mt-3 d-none">
        <label for="ios-upload" class="btn btn-warning">📱 Ghi âm iPhone</label>
        <input type="file" accept="audio/*" capture="microphone" id="ios-upload" class="d-none">
    </div>

    <audio id="audioPlayer" controls></audio>
    <div id="transcriptBox" class="mt-3 p-2 bg-light rounded shadow-sm">...</div>

    <script>
        let mediaRecorder;
        let audioChunks = [];

        function isIOS() {
            return /iPhone|iPad|iPod/.test(navigator.userAgent);
        }

        document.addEventListener('DOMContentLoaded', () => {
            if (isIOS()) {
                document.getElementById('start').classList.add('d-none');
                document.getElementById('stop').classList.add('d-none');
                document.getElementById('ios-mode').classList.remove('d-none');
            }

            document.getElementById('ios-upload').addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) return;
                sendToServer(file, file.name);
            });
        });

        document.getElementById('start').onclick = async () => {
            const stream = await navigator.mediaDevices.getUserMedia({
                audio: true
            });
            mediaRecorder = new MediaRecorder(stream, {
                mimeType: 'audio/webm;codecs=opus'
            });
            audioChunks = [];

            mediaRecorder.ondataavailable = e => {
                if (e.data.size > 0) audioChunks.push(e.data);
            };

            mediaRecorder.onstop = () => {
                const blob = new Blob(audioChunks, {
                    type: 'audio/webm'
                });
                sendToServer(blob, 'recording.webm');
            };

            mediaRecorder.start();
            document.getElementById('start').disabled = true;
            document.getElementById('stop').disabled = false;
        };

        document.getElementById('stop').onclick = () => {
            if (mediaRecorder && mediaRecorder.state === 'recording') {
                mediaRecorder.stop();
                document.getElementById('start').disabled = false;
                document.getElementById('stop').disabled = true;
            }
        };

        function sendToServer(blob, filename) {
            const formData = new FormData();
            formData.append('audio_data', blob, filename);

            fetch('<?php echo e(route('recorder.upload')); ?>', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    const box = document.getElementById('transcriptBox');
                    box.textContent = data.success ? data.text : '❌ ' + (data.message || 'Lỗi không xác định');
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/reading/recorder.blade.php ENDPATH**/ ?>