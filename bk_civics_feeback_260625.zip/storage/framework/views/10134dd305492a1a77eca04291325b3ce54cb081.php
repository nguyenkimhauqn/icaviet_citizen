<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <h3>Đại diện của bạn</h3>

    <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="mt-4"><?php echo e($office['name']); ?></h5>

        <?php $__currentLoopData = $office['officialIndices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $official = $officials[$index]; ?>
            <div class="card mb-2 p-3">
                <strong><?php echo e($official['name']); ?></strong><br>
                <?php echo e($official['party'] ?? 'Không rõ đảng'); ?><br>
                <?php if(isset($official['photoUrl'])): ?>
                    <img src="<?php echo e($official['photoUrl']); ?>" width="100">
                <?php endif; ?>
                <?php if(!empty($official['urls'])): ?>
                    <br><a href="<?php echo e($official['urls'][0]); ?>" target="_blank">Website</a>
                <?php endif; ?>
                <?php if(!empty($official['phones'])): ?>
                    <br>📞 <?php echo e($official['phones'][0]); ?>

                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <a href="/auth/redirect" class="btn btn-secondary mt-4">Tra cứu lại</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/representatives/result.blade.php ENDPATH**/ ?>