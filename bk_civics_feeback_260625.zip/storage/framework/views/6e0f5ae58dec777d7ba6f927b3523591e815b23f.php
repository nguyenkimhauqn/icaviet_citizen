<?php $__env->startSection('content'); ?>
        <h1>Ghi âm bằng micro và chuyển thành văn bản</h1>

        <button id="start">🎙️ Bắt đầu ghi âm</button>
        <button id="stop" disabled>⏹️ Dừng ghi</button>

        <audio id="player" controls></audio>
        <p><strong>Kết quả:</strong></p>
        <textarea id="result" rows="5" cols="60" readonly></textarea>

        <script>
            let mediaRecorder;
            let audioChunks = [];

            const startBtn = document.getElementById('start');
            const stopBtn = document.getElementById('stop');
            const resultBox = document.getElementById('result');

            startBtn.onclick = async () => {
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: true
                });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];

                mediaRecorder.ondataavailable = event => {
                    audioChunks.push(event.data);
                };

                mediaRecorder.onstop = async () => {
                    const blob = new Blob(audioChunks, {
                        type: 'audio/webm'
                    });
                    const audioUrl = URL.createObjectURL(blob);
                    document.getElementById('player').src = audioUrl;

                    const formData = new FormData();
                    formData.append('audio', blob, 'recording.webm');

                    const response = await fetch('/transcribe', {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                        },
                        body: formData
                    });

                    const data = await response.json();
                    resultBox.value = data.transcript || 'Không nhận dạng được nội dung.';
                };

                mediaRecorder.start();
                startBtn.disabled = true;
                stopBtn.disabled = false;
            };

            stopBtn.onclick = () => {
                mediaRecorder.stop();
                startBtn.disabled = false;
                stopBtn.disabled = true;
            };
        </script>

<?php $__env->stopSection(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/test/record.blade.php ENDPATH**/ ?>