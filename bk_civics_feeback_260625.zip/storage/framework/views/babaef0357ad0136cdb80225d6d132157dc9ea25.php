<div class="card mb-3" style="max-width: 400px;">
    <div class="row g-0">
        <div class="col-4">
            <img src="<?php echo e($person['photo']); ?>" class="img-fluid rounded-start" alt="<?php echo e($person['name']); ?>">
        </div>
        <div class="col-8">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($person['name']); ?></h5>
                <p class="card-text"><?php echo e($person['party']); ?></p>
                <a href="<?php echo e($person['url']); ?>" class="btn btn-sm btn-outline-primary" target="_blank">Trang web</a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/lookup/card.blade.php ENDPATH**/ ?>