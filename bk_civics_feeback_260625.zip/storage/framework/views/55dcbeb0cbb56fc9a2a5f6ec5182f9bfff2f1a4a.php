<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h2 class="mb-4">📍 ZIP: <?php echo e($officials['zip']); ?> – <?php echo e($officials['state']); ?></h2>

    <h4>🧑‍⚖️ Thống đốc</h4>
    <?php echo $__env->make('lookup.card', ['person' => $officials['governor']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h4 class="mt-4">👨‍💼 Thượng nghị sĩ</h4>
    <?php $__currentLoopData = $officials['senators']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('lookup.card', ['person' => $person], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <h4 class="mt-4">👩‍💼 Dân biểu</h4>
    <?php $__currentLoopData = $officials['representatives']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('lookup.card', ['person' => $person], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/lookup/result.blade.php ENDPATH**/ ?>