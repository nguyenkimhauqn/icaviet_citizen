    

    <?php $__env->startSection('content'); ?>
        <h2>🎙 Ghi âm giọng nói (Hỗ trợ Safari)</h2>

        <button id="start">▶️ Ghi âm</button>
        <button id="stop" disabled>⏹️ Dừng</button>
        <audio id="audioPlayer" controls></audio>
        <p><strong>Kết quả chuyển giọng nói:</strong></p>
        <textarea id="transcript" rows="5" cols="60" readonly></textarea>

        <!-- Đảm bảo bạn đã tải recorder.js từ https://github.com/mattdiamond/Recorderjs -->

        <script src="<?php echo e(URL('public/js/recorder.js')); ?>"></script>
        <script>
            let recorder, audioContext;
            // alert(1);
            document.getElementById('start').onclick = async () => {
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: true
                });
                audioContext = new(window.AudioContext || window.webkitAudioContext)();
                const input = audioContext.createMediaStreamSource(stream);
                recorder = new Recorder(input, {
                    numChannels: 1
                });

                recorder.record();
                document.getElementById('start').disabled = true;
                document.getElementById('stop').disabled = false;
            };

            document.getElementById('stop').onclick = () => {
                recorder.stop();
                recorder.exportWAV(sendWavToLaravel);

                document.getElementById('start').disabled = false;
                document.getElementById('stop').disabled = true;
            };

            function sendWavToLaravel(blob) {
                const url = URL.createObjectURL(blob);
                document.getElementById('audioPlayer').src = url;

                const formData = new FormData();
                formData.append('audio', blob, 'record.wav');

                fetch("<?php echo e(route('whisper.transcribe')); ?>", {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                        },
                        body: formData
                    })
                    .then(res => res.json())
                    .then(data => {
                        document.getElementById('transcript').value = data.transcript || 'Không có kết quả.';
                    })
                    .catch(err => {
                        alert("Lỗi khi gửi file: " + err.message);
                    });
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/reading/assemblyai.blade.php ENDPATH**/ ?>