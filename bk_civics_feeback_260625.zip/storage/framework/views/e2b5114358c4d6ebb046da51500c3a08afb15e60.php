<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-white flex items-center justify-center px-4 py-8 mt-4">
        <div class="w-full max-w-sm">
            
            <h4 class="text-center">
                Nhập ZIP code nơi ở của bạn
            </h4>

            
            <form method="POST" action="<?php echo e(route('getRepresentative')); ?>" class="text-center">
                <?php echo csrf_field(); ?>
                <div class="box-input">
                    <input type="text" name="zip" maxlength="5" inputmode="numeric" pattern="\d{5}" required
                        class="zip-input fs-3 form-control text-center text-xl font-semibold border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
                        placeholder="" />
                </div>

                <?php $__errorArgs = ['zip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="fs-5 text-red-600 text-sm mb-3 text-danger"><?php echo e($message . '!'); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <p class="text-center text-sm text-gray-700 leading-relaxed mb-6">
                    ZIP Code sẽ được sử dụng để tra cứu Thượng nghị sĩ (<strong class="font-semibold italic">U.S.
                        Senators</strong>),
                    Dân biểu của Hạ viện (<strong class="font-semibold italic">U.S. Representative</strong>),
                    Thống đốc (<strong class="font-semibold italic">Governor</strong>) và thủ phủ của tiểu bang
                    (<strong class="font-semibold italic">State Capital</strong>) trong khu vực bạn sống nhằm phục vụ cho
                    mục
                    đích học tập.
                </p>

                <button type="submit" class="btn btn-primary d-inline-flex align-items-center justify-content-center"
                    id="submitBtn">
                    <span class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true"
                        id="spinner"></span>
                    <span id="btnText">Tiếp theo</span>
                </button>
            </form>
        </div>
    </div>
    <style>
        .wp-content {
            margin: 0 auto;
            padding: 0 16px;
            max-width: 440px;
            box-sizing: border-box;
        }

        h4 {
            font-size: 22px !important;
            text-transform: uppercase;
            margin-top: 50px;
        }

        .box-input {
            margin: 20px 5px;
        }

        .zip-input {
            max-width: 332px;
            height: 59px;
            display: block;
            margin: 0 auto;
            align-items: center;
            background-color: #F8F7FB;
        }

        strong.italic {
            font-style: italic;
            font-weight: 600;
        }

        .btn-primary {
            padding: 15px 40px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            // alert(1);
            $(document).on('click', '#submitBtn', function() {
                $('#spinner').removeClass('d-none');
                $('#btnText').text('Đang xử lý...');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/representative/form.blade.php ENDPATH**/ ?>