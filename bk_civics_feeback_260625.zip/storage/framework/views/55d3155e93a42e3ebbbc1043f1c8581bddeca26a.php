<?php $__env->startSection('content'); ?>
    <div class="container-mobile row justify-content-center">
        <div class="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5">

            
            <div class="card-head text-center banner-wrapper">
                <img src="<?php echo e(asset('public/banners/banner-login.png')); ?>" alt="Banner" class="img-fluid">
            </div>

            <div class="card card-body">
                <h3 class="text-start mb-4 font-weight-bold">Đăng nhập</h3>

                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <div class="form-group mb-3">
                        <input id="email" type="email" placeholder="Nhập email"
                            class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                            value="<?php echo e(old('email')); ?>" required autofocus>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="form-group mb-3 position-relative" style="position: relative;">
                        <input id="password" type="password" placeholder="Nhập mật khẩu"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required>

                        
                        <i class="bi bi-eye toggle-password icon-inside-input" onclick="togglePassword()"></i>

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <div class="form-group d-flex justify-content-between align-items-center mb-4">
                        <!-- Bên trái: checkbox + label -->
                        <div class="d-flex align-items-center">
                            <input type="checkbox" name="remember" id="remember" class="checkbox-scaled me-2">
                            <label for="remember" class="mb-0">Ghi nhớ đăng nhập</label>
                        </div>

                        <!-- Bên phải: link quên mật khẩu -->
                        <div class="d-flex align-items-center">
                            <a href="<?php echo e(route('password.request')); ?>" class="mb-0">Quên mật khẩu?</a>
                        </div>
                    </div>

                    
                    <div class="form-group mb-3">
                        <button type="submit" class="btn btn-primary w-30">Đăng nhập</button>
                    </div>

                    
                    <div class="text-start">
                        Bạn chưa có tài khoản?
                        <a class="register" href="<?php echo e(route('register')); ?>">Đăng ký ngay</a>
                    </div>
            </div>
            </form>
        </div>
    </div>

    <style>
        .card {
            background-color: #FFFFFF;
            border-top-left-radius: 12px !important;
            border-top-right-radius: 12px;
            !important;
            border: none !important;
        }

        .card .text-start {
            color: #0B0B0B !important;
        }

        .form-control {
            background-color: #F8F7FB !important;
            height: 50px !important;
            border: none !important;
        }

        .checkbox-scaled {
            transform: scale(1);
            /* ~ 16px * 1.5 = 24px */
            transform-origin: top left;
            width: 25px;
            height: 25px;
            cursor: pointer;
        }

        label {
            margin-bottom: 0px !important;
        }

        .btn-primary {
            color: #fff;
            padding: 10px 30px 10px 30px;
            background-color: #1247BB;
            border-color: #1247BB;
        }

        .forget-password {
            color: #0B0B0B;
            font-weight: 600;
        }

        .register {
            color: #1247BB;
            font-weight: 600;
        }

        .navbar-light .navbar-toggler-icon {
            background-image: url('public/icon/align-justify.svg') !important;
            background-size: contain;
            background-repeat: no-repeat;
        }

        .navbar-light .navbar-toggler {
            border: none !important;
        }

        .img-fluid {
            width: 100%;
            height: auto;
        }

        .icon-inside-input {
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            font-size: 1.2rem;
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        // Ẩn/ hiện mật khẩu: 
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.querySelector('.toggle-password');

            const isHidden = passwordInput.type === 'password';
            passwordInput.type = isHidden ? 'text' : 'password';

            toggleIcon.classList.toggle('bi-eye');
            toggleIcon.classList.toggle('bi-eye-slash');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/icaviet_citizen/resources/views/auth/login.blade.php ENDPATH**/ ?>